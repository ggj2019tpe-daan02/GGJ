﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "CreateGridData")]
public class GridPrefabPool : ScriptableObject {

    public GameObject[] obj;
}
