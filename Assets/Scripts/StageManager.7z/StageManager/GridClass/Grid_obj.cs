﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grid_obj : Grid_Basic {
    
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public virtual void OnPlayerTouch()
    {

    }
}
